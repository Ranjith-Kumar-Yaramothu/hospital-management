-- =====================================================
-- Hospital Management System - UPGRADE SCRIPT
-- Run ONCE, after hospital_management_system.sql
-- Workbench: select all (Ctrl+A) then Ctrl+Shift+Enter
-- =====================================================

USE hospital_db;

-- Patient email (needed for email features)
ALTER TABLE patients ADD COLUMN email VARCHAR(120) NULL AFTER phone;

-- Doctor availability (weekly schedule)
CREATE TABLE doctor_availability (
    avail_id    INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id   INT NOT NULL,
    day_of_week ENUM('Mon','Tue','Wed','Thu','Fri','Sat','Sun') NOT NULL,
    start_time  TIME NOT NULL,
    end_time    TIME NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id),
    CHECK (end_time > start_time)
);

-- Payments (a bill can be paid in parts)
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    bill_id    INT NOT NULL,
    amount     DECIMAL(10,2) NOT NULL CHECK (amount > 0),
    method     ENUM('Cash','Card','UPI','Insurance') NOT NULL,
    paid_on    DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id)
);

-- Default availability: Mon-Sat, 09:00-17:00 for every doctor
INSERT INTO doctor_availability (doctor_id, day_of_week, start_time, end_time)
SELECT d.doctor_id, x.dow, '09:00:00', '17:00:00'
FROM doctors d
JOIN (SELECT 'Mon' AS dow UNION ALL SELECT 'Tue' UNION ALL SELECT 'Wed'
      UNION ALL SELECT 'Thu' UNION ALL SELECT 'Fri' UNION ALL SELECT 'Sat') x;

DELIMITER $$

-- Booking now also checks doctor availability
DROP PROCEDURE IF EXISTS sp_book_appointment$$
CREATE PROCEDURE sp_book_appointment(
    IN p_patient_id INT,
    IN p_doctor_id  INT,
    IN p_date       DATE,
    IN p_time       TIME,
    IN p_reason     VARCHAR(200)
)
BEGIN
    IF p_date < CURRENT_DATE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot book an appointment in the past';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM doctor_availability
                   WHERE doctor_id = p_doctor_id
                     AND day_of_week = LEFT(DAYNAME(p_date), 3)
                     AND p_time >= start_time
                     AND p_time <  end_time) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Doctor is not available on this day/time';
    END IF;

    IF EXISTS (SELECT 1 FROM appointments
               WHERE doctor_id = p_doctor_id
                 AND appt_date = p_date
                 AND appt_time = p_time
                 AND status <> 'Cancelled') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Doctor already has an appointment at this slot';
    END IF;

    INSERT INTO appointments (patient_id, doctor_id, appt_date, appt_time, reason)
    VALUES (p_patient_id, p_doctor_id, p_date, p_time, p_reason);

    SELECT LAST_INSERT_ID() AS new_appointment_id;
END$$

-- Cancel an appointment (only if still scheduled)
CREATE PROCEDURE sp_cancel_appointment(IN p_appointment_id INT)
BEGIN
    DECLARE v_status VARCHAR(20);

    SELECT status INTO v_status FROM appointments WHERE appointment_id = p_appointment_id;

    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Appointment not found';
    END IF;
    IF v_status <> 'Scheduled' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only scheduled appointments can be cancelled';
    END IF;

    UPDATE appointments SET status = 'Cancelled' WHERE appointment_id = p_appointment_id;
END$$

-- Record a payment (cannot exceed the bill balance)
CREATE PROCEDURE sp_record_payment(
    IN p_bill_id INT,
    IN p_amount  DECIMAL(10,2),
    IN p_method  VARCHAR(20)
)
BEGIN
    DECLARE v_total DECIMAL(10,2);
    DECLARE v_paid  DECIMAL(10,2);

    SELECT total_amount INTO v_total FROM bills WHERE bill_id = p_bill_id;
    IF v_total IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Bill not found';
    END IF;

    SELECT COALESCE(SUM(amount), 0) INTO v_paid FROM payments WHERE bill_id = p_bill_id;
    IF v_paid + p_amount > v_total THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Payment exceeds the bill balance';
    END IF;

    INSERT INTO payments (bill_id, amount, method) VALUES (p_bill_id, p_amount, p_method);
END$$

-- Mark the bill as Paid once payments cover the total
CREATE TRIGGER trg_update_bill_status
AFTER INSERT ON payments
FOR EACH ROW
BEGIN
    UPDATE bills
    SET payment_status = 'Paid'
    WHERE bill_id = NEW.bill_id
      AND (SELECT SUM(amount) FROM payments WHERE bill_id = NEW.bill_id) >= total_amount;
END$$

DELIMITER ;

-- Quick checks
SELECT * FROM doctor_availability;
SHOW TABLES;
